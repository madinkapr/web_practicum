import "@css/main.css"
import { io } from "socket.io-client"

const messagesBox = document.querySelector(".messages")
const input = document.querySelector(".chat-input")

let username = prompt("Ismingizni kiriting:")

while (!username || !username.trim()) {
    username = prompt("Iltimos, ismingizni kiriting:")
}

username = username.trim()

const server = io("http://localhost:3000")

function renderMessage(message) {
    const wrapper = document.createElement("div")
    const name = document.createElement("div")
    const text = document.createElement("div")

    const isMine = message.userId === server.id

    wrapper.classList.add("message")
    wrapper.classList.add(isMine ? "mine" : "other")

    name.classList.add("username")
    text.classList.add("text")

    name.textContent = message.username
    name.style.color = message.color ?? "#ffffff"
    text.textContent = message.text

    wrapper.appendChild(name)
    wrapper.appendChild(text)
    messagesBox.appendChild(wrapper)

    messagesBox.scrollTop = messagesBox.scrollHeight
}

server.on("PREV_MESSAGES", (messages) => {
    messagesBox.innerHTML = ""

    for (const m of messages) {
        renderMessage(m)
    }
})

input.addEventListener("keyup", e => {

    if (e.code === "Enter") {
        const text = input.value.trim()
        if (!text) return

        server.emit("NEW_MESSAGE_FROM_BROWSER_BY_INPUT", {
            username, text
        })

        input.value = ""
    }
})

server.on("NEW_MESSAGE_FROM_SERVER", message => {

    renderMessage(message)
})
